import streamlit as st
import pandas as pd

from utils.styles import load_styles
from utils.mitre import get_mitre_context


load_styles()

st.title("Detection Rules")
st.caption("Detection engineering logic and MITRE ATT&CK coverage for AEGIS authentication analytics.")

rules = pd.DataFrame([
    {
        "Rule ID": "RULE-1001",
        "Rule Name": "Brute Force Detection",
        "Condition": "5+ failed logins against the same user from the same IP within 15 minutes",
        "Severity": "Medium / High / Critical",
        "MITRE": "T1110 - Brute Force",
        "Tactic": "Credential Access",
    },
    {
        "Rule ID": "RULE-1002",
        "Rule Name": "Impossible Travel",
        "Condition": "Same user successfully authenticates from different countries within 60 minutes",
        "Severity": "High",
        "MITRE": "T1078 - Valid Accounts",
        "Tactic": "Valid Account Abuse",
    },
    {
        "Rule ID": "RULE-1003",
        "Rule Name": "Password Spray Detection",
        "Condition": "Same source IP attempts failed authentication against 5+ unique user accounts",
        "Severity": "High",
        "MITRE": "T1110.003 - Password Spraying",
        "Tactic": "Credential Access",
    },
    {
        "Rule ID": "RULE-1004",
        "Rule Name": "Account Takeover Detection",
        "Condition": "5+ failed logins followed by a successful authentication for the same user and source IP",
        "Severity": "Critical",
        "MITRE": "T1078 - Valid Accounts",
        "Tactic": "Valid Account Abuse",
    },
])

st.dataframe(rules, use_container_width=True, hide_index=True)

st.divider()
st.subheader("ATT&CK Coverage")

for mitre_value in ["T1110 - Brute Force", "T1110.003 - Password Spraying", "T1078 - Valid Accounts"]:
    context = get_mitre_context(mitre_value=mitre_value)

    with st.expander(f"{context['technique_id']} — {context['name']}"):
        st.write(f"**Tactic:** {context['tactic']}")
        st.write(context["description"])
        st.write("**AEGIS response guidance:**")
        for action in context["recommended_actions"]:
            st.markdown(f"- {action}")
