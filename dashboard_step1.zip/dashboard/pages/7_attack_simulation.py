# pages/7_attack_simulation.py

import streamlit as st

from utils.styles import load_styles
from utils.simulations import (
    simulate_brute_force,
    simulate_password_spray,
    simulate_impossible_travel,
    simulate_compromised_account,
)


load_styles()


st.title("Attack Simulation")

st.caption(
    "Generate controlled authentication attack patterns "
    "to validate AEGIS detections and incident workflows."
)


st.warning(
    "Simulation mode is active. Generated events are written "
    "to the AEGIS security event database."
)


st.divider()


col1, col2 = st.columns(2)


with col1:

    st.subheader("Brute Force")

    st.caption(
        "Repeated failed authentication attempts against "
        "a single account from the same source."
    )

    if st.button(
        "Simulate Brute Force",
        use_container_width=True,
    ):

        source_ip, username, country = (
            simulate_brute_force()
        )

        st.cache_data.clear()

        st.error(
            f"Brute-force activity generated against "
            f"`{username}` from `{source_ip}` ({country})."
        )


with col2:

    st.subheader("Password Spray")

    st.caption(
        "A single source attempts authentication across "
        "multiple user accounts."
    )

    if st.button(
        "Simulate Password Spray",
        use_container_width=True,
    ):

        source_ip, sprayed_users, country = (
            simulate_password_spray()
        )

        st.cache_data.clear()

        st.warning(
            f"Password spray generated from `{source_ip}` "
            f"({country}) against "
            f"{len(sprayed_users)} accounts."
        )


st.divider()


col3, col4 = st.columns(2)


with col3:

    st.subheader("Impossible Travel")

    st.caption(
        "Successful logins for one account from "
        "geographically distant locations."
    )

    if st.button(
        "Simulate Impossible Travel",
        use_container_width=True,
    ):

        (
            username,
            source_ip_1,
            country_1,
            source_ip_2,
            country_2,
        ) = simulate_impossible_travel()

        st.cache_data.clear()

        st.warning(
            f"Impossible-travel scenario generated for "
            f"`{username}`: {country_1} → {country_2}."
        )


with col4:

    st.subheader("Compromised Account")

    st.caption(
        "Multiple failures followed by a successful "
        "authentication from the same source."
    )

    if st.button(
        "Simulate Compromised Account",
        use_container_width=True,
    ):

        source_ip, username, country = (
            simulate_compromised_account()
        )

        st.cache_data.clear()

        st.error(
            f"Potential account takeover generated for "
            f"`{username}` from `{source_ip}` ({country})."
        )