import streamlit as st
import pandas as pd
from db import get_connection


@st.cache_data(ttl=30)
def load_data(hours=24):
    conn = get_connection()

    query = """
        SELECT
            event_id,
            event_time,
            source_ip,
            username,
            event_type,
            status,
            geo_country,
            device_type,
            latitude,
            longitude
        FROM events
        WHERE event_time >= NOW() - INTERVAL %s HOUR
        ORDER BY event_time DESC
    """

    df = pd.read_sql(
        query,
        conn,
        params=(hours,)
    )

    conn.close()

    df["event_time"] = pd.to_datetime(
        df["event_time"],
        errors="coerce"
    )

    df["latitude"] = pd.to_numeric(
        df["latitude"],
        errors="coerce"
    )

    df["longitude"] = pd.to_numeric(
        df["longitude"],
        errors="coerce"
    )

    return df