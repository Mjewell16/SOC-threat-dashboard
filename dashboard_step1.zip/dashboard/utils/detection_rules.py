DETECTION_RULES = {
    "brute_force": {
        "rule_id": "AEGIS-001",
        "name": "Brute Force",
        "incident_type": "Brute Force",
        "threshold": 10,
        "severity": "High / Critical",
        "mitre": "T1110",
        "mitre_name": "Brute Force",
        "tactic": "Credential Access",
        "description": (
            "Detects repeated failed authentication attempts "
            "against the same user from the same source IP."
        ),
        "condition": (
            "10+ failed authentication attempts against the "
            "same user from the same source IP."
        ),
    },

    "password_spray": {
        "rule_id": "AEGIS-002",
        "name": "Password Spray",
        "incident_type": "Password Spray",
        "unique_user_threshold": 5,
        "severity": "High",
        "mitre": "T1110.003",
        "mitre_name": "Password Spraying",
        "tactic": "Credential Access",
        "description": (
            "Detects a single source IP attempting authentication "
            "against multiple user accounts."
        ),
        "condition": (
            "Failed authentication attempts from the same source "
            "IP against 5+ unique user accounts."
        ),
    },

    "account_takeover": {
        "rule_id": "AEGIS-003",
        "name": "Potential Account Takeover",
        "incident_type": "Potential Account Takeover",
        "failure_threshold": 5,
        "severity": "Critical",
        "mitre": "T1078",
        "mitre_name": "Valid Accounts",
        "tactic": (
            "Initial Access / Persistence / "
            "Privilege Escalation / Defense Evasion"
        ),
        "description": (
            "Detects repeated failed authentication attempts "
            "followed by a successful authentication."
        ),
        "condition": (
            "5+ failed authentication attempts followed by a "
            "successful login for the same user and source IP."
        ),
    },

    "impossible_travel": {
        "rule_id": "AEGIS-004",
        "name": "Impossible Travel",
        "incident_type": "Impossible Travel",
        "time_threshold_minutes": 60,
        "severity": "High",
        "mitre": "T1078",
        "mitre_name": "Valid Accounts",
        "tactic": (
            "Initial Access / Persistence / "
            "Privilege Escalation / Defense Evasion"
        ),
        "description": (
            "Detects successful authentications for the same user "
            "from different countries within an implausible "
            "period of time."
        ),
        "condition": (
            "Successful authentications for the same user from "
            "different countries within 60 minutes."
        ),
    },
}