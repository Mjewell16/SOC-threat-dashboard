import pandas as pd


def detect_impossible_travel(df):
    """
    Detect successful authentications for the same user
    from different countries within 60 minutes.

    MITRE ATT&CK:
        T1078 - Valid Accounts
    """

    if df.empty:
        return pd.DataFrame()

    required_columns = {
        "username",
        "event_time",
        "geo_country",
        "source_ip",
        "status"
    }

    if not required_columns.issubset(df.columns):
        return pd.DataFrame()

    # Impossible travel should only use successful logins
    successful_logins = df[
        df["status"] == "success"
    ].copy()

    if successful_logins.empty:
        return pd.DataFrame()

    successful_logins["event_time"] = pd.to_datetime(
        successful_logins["event_time"]
    )

    impossible_travel_alerts = []

    for username in successful_logins["username"].dropna().unique():

        user_events = (
            successful_logins[
                successful_logins["username"] == username
            ]
            .sort_values("event_time")
        )

        previous_country = None
        previous_time = None
        previous_ip = None

        for _, row in user_events.iterrows():

            current_country = row["geo_country"]
            current_time = row["event_time"]
            current_ip = row["source_ip"]

            if (
                previous_country is not None
                and previous_time is not None
            ):

                time_difference = (
                    current_time - previous_time
                ).total_seconds() / 60

                if (
                    current_country != previous_country
                    and 0 <= time_difference < 60
                ):

                    impossible_travel_alerts.append({
                        "username": username,
                        "from_country": previous_country,
                        "to_country": current_country,
                        "from_ip": previous_ip,
                        "to_ip": current_ip,
                        "minutes_between": round(
                            time_difference,
                            2
                        ),
                        "severity": "High",
                        "incident_type": "Impossible Travel",
                        "mitre": "T1078 - Valid Accounts",
                        "mitre_tactic": "Initial Access / Persistence / Privilege Escalation / Defense Evasion",
                        "detection_summary": (
                            f"Successful logins for {username} occurred in {previous_country} and "
                            f"{current_country} only {round(time_difference, 2)} minutes apart."
                        )
                    })

            previous_country = current_country
            previous_time = current_time
            previous_ip = current_ip

    return pd.DataFrame(
        impossible_travel_alerts
    )